# Gitcoin CLI

Este es un ejemplo de aplicación de línea de comandos (CLI) lista para usar con Docker y subir a GitHub para bounties o hackathons en Gitcoin.

## 🚀 Uso rápido

```bash
docker build -t gitcoin-cli .
docker run gitcoin-cli TuNombre
```

## 🔧 Archivos

- `cli.py`: Script principal
- `Dockerfile`: Configura el entorno en Docker
- `requirements.txt`: Dependencias (vacío por ahora)

## 📦 Ejemplo de salida

```
¡Hola, Nogalitos! Bienvenido al proyecto Gitcoin CLI.
```

## ✨ Listo para subir a GitHub y participar en bounties.
