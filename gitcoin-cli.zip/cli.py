import sys

def main():
    if len(sys.argv) < 2:
        print("Uso: docker run gitcoin-cli <tu_nombre>")
        return
    nombre = sys.argv[1]
    print(f"¡Hola, {nombre}! Bienvenido al proyecto Gitcoin CLI.")

if __name__ == "__main__":
    main()
