import requests

ETHERSCAN_API_KEY = "YourApiKeyHere"  # Reemplaza con tu clave real
ETH_ADDRESS = "0xff592f38Ce217E08f12c2f8Da33099f64Ac1DE52"

def get_eth_balance(address):
    url = f"https://api.etherscan.io/api?module=account&action=balance&address={address}&tag=latest&apikey={ETHERSCAN_API_KEY}"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        if data["status"] == "1":
            balance_wei = int(data["result"])
            balance_eth = balance_wei / (10 ** 18)
            return balance_eth
        else:
            return "Error en respuesta de Etherscan"
    else:
        return "No se pudo conectar a Etherscan"

def main():
    while True:
        print("\n🌱 Gitcoin CLI - Proyecto Nogalitos")
        print("1. Saludar")
        print("2. Ver saldo ETH")
        print("3. Salir")
        opcion = input("Selecciona una opción (1-3): ")

        if opcion == "1":
            nombre = input("¿Cuál es tu nombre? ")
            print(f"¡Hola, {nombre}! Bienvenido al Proyecto Gitcoin CLI 🌱")
        elif opcion == "2":
            print("Consultando saldo en Ethereum...")
            balance = get_eth_balance(ETH_ADDRESS)
            print(f"💰 Saldo de {ETH_ADDRESS[:6]}...{ETH_ADDRESS[-4:]}: {balance} ETH")
        elif opcion == "3":
            print("¡Hasta pronto! ✨")
            break
        else:
            print("Opción no válida. Intenta de nuevo.")

if __name__ == "__main__":
    main()
