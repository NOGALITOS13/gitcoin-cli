# 🌱 Gitcoin CLI - Proyecto Nogalitos

Una herramienta CLI con Docker que saluda al usuario y muestra el saldo en Ethereum de la wallet principal del proyecto.

## 🚀 ¿Qué hace?

- Recibe tu nombre desde terminal
- Consulta el saldo actual de la wallet de Proyecto Nogalitos en Ethereum
- Ideal para aprender Web3, usar en hackathons o presentar como plantilla en Gitcoin

## 🐳 Cómo correrlo

```bash
docker build -t gitcoin-cli .
docker run gitcoin-cli TuNombre
```

> Resultado esperado:
```
¡Hola, TuNombre! Bienvenido al Proyecto Gitcoin CLI 🌱

Consultando saldo de tu wallet en Ethereum...
💰 Saldo de 0xff59...DE52: 0.034 ETH
```

## 🌐 Datos del Proyecto

**GitHub:** [github.com/nogalitos13](https://github.com/nogalitos13)  
**Wallet Ethereum/Base:** `0xff592f38Ce217E08f12c2f8Da33099f64Ac1DE52`  
**Twitter/X:** [@JawSoto](https://twitter.com/JawSoto)  
**Email:** angelquijadasoto2020@gmail.com

---

## 🔐 Nota sobre Etherscan API

Este CLI usa la API pública de [Etherscan](https://etherscan.io/apis), pero puedes registrar tu propia clave gratis para producción y reemplazar `"YourApiKeyHere"` en `cli.py`.

---

## 🤝 Licencia

MIT — Hazlo tuyo, hazlo libre.
